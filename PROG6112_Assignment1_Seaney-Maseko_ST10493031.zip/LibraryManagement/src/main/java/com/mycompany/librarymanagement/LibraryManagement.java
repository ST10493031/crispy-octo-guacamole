/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.librarymanagement;
import java.util.Scanner;
/**
 *
 * @author RC_Student_lab
 */

public class LibraryManagement {
    private Book[] inventory;
    private Book[] cart;
    private int inventoryCount = 0;
    private int cartCount = 0;

    public LibraryManagement(int maxInventorySize, int maxCartSize) {
        inventory = new Book[maxInventorySize];
        cart = new Book[maxCartSize];
    }

    public void loadSampleBooks() {
        inventory[inventoryCount++] = new Fiction("1984", "George Orwell", 15.99, "Dystopian");
        inventory[inventoryCount++] = new NonFiction("Sapiens", "Yuval Noah Harari", 20.50, "History");
        inventory[inventoryCount++] = new Fiction("Harry Potter", "J.K. Rowling", 12.99, "Fantasy");
        inventory[inventoryCount++] = new NonFiction("Educated", "Tara Westover", 18.00, "Memoir");
    }

    public void showMenu() {
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n====== LIBRARY MANAGEMENT SYSTEM ======");
            System.out.println("1. View All Books");
            System.out.println("2. View Fiction Books");
            System.out.println("3. View Non-Fiction Books");
            System.out.println("4. Buy a Book");
            System.out.println("5. View Cart");
            System.out.println("6. Checkout and Exit");
            System.out.print("Choose an option: ");
            choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (choice) {
                case 1 -> displayBooks("All");
                case 2 -> displayBooks("Fiction");
                case 3 -> displayBooks("Non-Fiction");
                case 4 -> buyBook(scanner);
                case 5 -> displayCart();
                case 6 -> checkout();
                default -> System.out.println("Invalid choice. Please try again.");
            }

        } while (choice != 6);

        scanner.close();
    }

    private void displayBooks(String category) {
        System.out.println("\n--- AVAILABLE BOOKS ---");
        for (int i = 0; i < inventoryCount; i++) {
            Book book = inventory[i];
            if (category.equals("All") || book.getCategory().equalsIgnoreCase(category)) {
                System.out.println((i + 1) + ". " + book.toString());
            }
        }
    }

    private void buyBook(Scanner scanner) {
        displayBooks("All");
        System.out.print("Enter the number of the book to buy: ");
        int bookNumber = scanner.nextInt();
        scanner.nextLine(); // consume newline

        if (bookNumber < 1 || bookNumber > inventoryCount) {
            System.out.println("Invalid book number!");
            return;
        }

        if (cartCount < cart.length) {
            cart[cartCount++] = inventory[bookNumber - 1];
            System.out.println("Book added to cart.");
        } else {
            System.out.println("Cart is full!");
        }
    }

    private void displayCart() {
        if (cartCount == 0) {
            System.out.println("Your cart is empty.");
            return;
        }

        System.out.println("\n--- YOUR CART ---");
        double total = 0;
        for (int i = 0; i < cartCount; i++) {
            System.out.println((i + 1) + ". " + cart[i].toString());
            total += cart[i].getPrice();
        }
        System.out.printf("Total: $%.2f\n", total);
    }

    private void checkout() {
        System.out.println("\n===== CHECKOUT REPORT =====");
        displayCart();
        System.out.println("Thank you for using Library Management!");
    }

    public static void main(String[] args) {
        LibraryManagement app = new LibraryManagement(20, 5);
        app.loadSampleBooks();
        app.showMenu();
    }

    // --- Helper methods for JUnit tests below ---

    public Book getBookByIndex(int index) {
        if (index >= 0 && index < inventoryCount) {
            return inventory[index];
        }
        return null;
    }

    public boolean addToCartByIndex(int index) {
        if (index >= 0 && index < inventoryCount) {
            if (cartCount < cart.length) {
                cart[cartCount++] = inventory[index];
                return true;
            }
        }
        return false;
    }

    public int getCartCount() {
        return cartCount;
    }

    public double getCartTotal() {
        double total = 0;
        for (int i = 0; i < cartCount; i++) {
            total += cart[i].getPrice();
        }
        return total;
    }
}
