/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.librarymanagement;

/**
 *
 * @author RC_Student_lab
 */
public class NonFiction extends Book {
    private String field;

    public NonFiction(String title, String author, double price, String field) {
        super(title, author, price);
        this.field = field;
    }

    @Override
    public String getCategory() {
        return "Non-Fiction";
    }

    public String getField() {
        return field;
    }

    @Override
    public String toString() {
        return super.toString() + " | Field: " + field;
    }
}

