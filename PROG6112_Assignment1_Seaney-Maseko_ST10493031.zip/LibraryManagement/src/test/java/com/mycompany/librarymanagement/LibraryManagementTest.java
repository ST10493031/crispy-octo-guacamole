/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.librarymanagement;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


/**
 *
 * @author RC_Student_lab
 */

public class LibraryManagementTest {
    private LibraryManagement app;

    @BeforeEach
    public void setUp() {
        app = new LibraryManagement(10, 5);
        app.loadSampleBooks();
    }

    @Test
    public void testInventoryLoadedCorrectly() {
        Book book = app.getBookByIndex(0);
        assertNotNull(book);
        assertEquals("1984", book.getTitle());
    }

    @Test
    public void testAddToCart() {
        boolean success = app.addToCartByIndex(0);
        assertTrue(success);
        assertEquals(1, app.getCartCount());
    }

    @Test
    public void testCartTotalPrice() {
        app.addToCartByIndex(0); // $15.99
        app.addToCartByIndex(1); // $20.50
        double total = app.getCartTotal();
        assertEquals(36.49, total, 0.01); // floating-point tolerance
    }

    @Test
    public void testInvalidBookIndex() {
        boolean success = app.addToCartByIndex(20); // invalid
        assertFalse(success);
        assertEquals(0, app.getCartCount());
    }
}
