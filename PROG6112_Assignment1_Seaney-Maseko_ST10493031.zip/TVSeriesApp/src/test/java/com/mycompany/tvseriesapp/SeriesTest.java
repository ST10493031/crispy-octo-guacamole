/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.tvseriesapp;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class SeriesTest {
    Series series;

    @BeforeEach
    public void setUp() {
        series = new Series();
        series.seriesList.add(new SeriesModel("S001", "Friends", "13", "24"));
    }

    @Test
    public void TestSearchSeries() {
        SeriesModel result = series.SearchSeries("S001");
        assertNotNull(result);
        assertEquals("Friends", result.seriesName);
    }

    @Test
    public void TestSearchSeries_SeriesNotFound() {
        SeriesModel result = series.SearchSeries("S999");
        assertNull(result);
    }

    @Test
    public void TestUpdateSeries() {
        SeriesModel s = series.SearchSeries("S001");
        s.seriesName = "Updated Name";
        assertEquals("Updated Name", series.SearchSeries("S001").seriesName);
    }

    @Test
    public void TestDeleteSeries() {
        SeriesModel s = series.SearchSeries("S001");
        series.seriesList.remove(s);
        assertNull(series.SearchSeries("S001"));
    }

    @Test
    public void TestDeleteSeries_SeriesNotFound() {
        int initialSize = series.seriesList.size();
        SeriesModel s = series.SearchSeries("S999");
        if (s != null) {
            series.seriesList.remove(s);
        }
        assertEquals(initialSize, series.seriesList.size());
    }

    @Test
    public void TestSeriesAgeRestriction_AgeValid() {
        assertTrue(series.isValidAge("12"));
    }

    @Test
    public void TestSeriesAgeRestriction_SeriesAgeInvalid() {
        assertFalse(series.isValidAge("25"));  // out of range
        assertFalse(series.isValidAge("abc")); // not a number
    }
}
