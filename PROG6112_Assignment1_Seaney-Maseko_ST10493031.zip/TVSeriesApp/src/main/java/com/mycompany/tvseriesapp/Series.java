/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tvseriesapp;

import java.util.ArrayList;
import java.util.Scanner;

public class Series {
    Scanner scanner = new Scanner(System.in);
    ArrayList<SeriesModel> seriesList = new ArrayList<>();

    public void CaptureSeries() {
        System.out.print("Enter Series ID: ");
        String id = scanner.nextLine();

        System.out.print("Enter Series Name: ");
        String name = scanner.nextLine();

        String age;
        while (true) {
            System.out.print("Enter Age Restriction (2-18): ");
            age = scanner.nextLine();
            if (isValidAge(age)) break;
            System.out.println("Invalid age. Please enter a number between 2 and 18.");
        }

        System.out.print("Enter Number of Episodes: ");
        String episodes = scanner.nextLine();

        seriesList.add(new SeriesModel(id, name, age, episodes));
        System.out.println("Series captured successfully!\n");
    }

    boolean isValidAge(String input) {
        try {
            int age = Integer.parseInt(input);
            return age >= 2 && age <= 18;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    public SeriesModel SearchSeries(String id) {
        for (SeriesModel s : seriesList) {
            if (s.seriesId.equalsIgnoreCase(id)) {
                return s;
            }
        }
        return null;
    }

    public void SearchSeries() {
        System.out.print("Enter Series ID to search: ");
        String id = scanner.nextLine();
        SeriesModel s = SearchSeries(id);
        if (s != null) {
            System.out.println("Series Found:\n" + s);
        } else {
            System.out.println("No series data found.");
        }
    }

    public void UpdateSeries() {
        System.out.print("Enter Series ID to update: ");
        String id = scanner.nextLine();
        SeriesModel s = SearchSeries(id);

        if (s != null) {
            System.out.print("Enter New Series Name: ");
            s.seriesName = scanner.nextLine();

            String age;
            while (true) {
                System.out.print("Enter New Age Restriction (2-18): ");
                age = scanner.nextLine();
                if (isValidAge(age)) break;
                System.out.println("Invalid age.");
            }
            s.seriesAge = age;

            System.out.print("Enter New Number of Episodes: ");
            s.seriesNumberOfEpisodes = scanner.nextLine();

            System.out.println("Series updated successfully!\n");
        } else {
            System.out.println("Series not found.\n");
        }
    }

    public void DeleteSeries() {
        System.out.print("Enter Series ID to delete: ");
        String id = scanner.nextLine();
        SeriesModel s = SearchSeries(id);

        if (s != null) {
            System.out.print("Are you sure you want to delete this series? (yes/no): ");
            String confirm = scanner.nextLine();
            if (confirm.equalsIgnoreCase("yes")) {
                seriesList.remove(s);
                System.out.println("Series deleted successfully!\n");
            } else {
                System.out.println("Delete cancelled.\n");
            }
        } else {
            System.out.println("Series not found.\n");
        }
    }

    public void SeriesReport() {
        System.out.println("TV Series Report:");
        for (SeriesModel s : seriesList) {
            System.out.println("---------------------------------");
            System.out.println(s);
        }
        if (seriesList.isEmpty()) {
            System.out.println("No series available.");
        }
        System.out.println();
    }

    public void ExitSeriesApplication() {
        System.out.println("Exiting... Goodbye!");
        System.exit(0);
    }
}
