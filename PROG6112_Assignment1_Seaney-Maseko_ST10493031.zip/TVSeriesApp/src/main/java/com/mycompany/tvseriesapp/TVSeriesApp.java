/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tvseriesapp;
import java.util.*;


public class TVSeriesApp {
    public static void main(String[] args) {
        Series series = new Series();
        Scanner scanner = new Scanner(System.in);
        int option;

        while (true) {
            System.out.println("\n--- TV Series Management Menu ---");
            System.out.println("1. Capture Series");
            System.out.println("2. Search Series");
            System.out.println("3. Update Series");
            System.out.println("4. Delete Series");
            System.out.println("5. View Report");
            System.out.println("6. Exit");
            System.out.print("Select an option: ");
            
            try {
                option = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.\n");
                continue;
            }

            switch (option) {
                case 1:
                    series.CaptureSeries();
                    break;
                case 2:
                    series.SearchSeries();
                    break;
                case 3:
                    series.UpdateSeries();
                    break;
                case 4:
                    series.DeleteSeries();
                    break;
                case 5:
                    series.SeriesReport();
                    break;
                case 6:
                    series.ExitSeriesApplication();
                    break;
                default:
                    System.out.println("Invalid option. Please try again.\n");
            }
        }
    }
}
